BRAIN INTERACTS - LOGO FILES
A People Analytics Company

COLOURS
  Red     #B91C1C  (head)
  Yellow  #FACC15  (body)
  Navy    #172554  (collar, divider, tagline)
  Ink     #1E1B2E  (name)

FOLDERS
  SVG/            Sharp at any size. Use these on the website wherever possible.
  PNG/            Transparent background, in 3 sizes each. Use where SVG isn't accepted.
  Website-icons/  Browser tab icon (favicon), phone home-screen icons.
  Social/         Link-preview image and profile picture.

VERSIONS
  color       Normal logo for white / light backgrounds  (DEFAULT)
  reversed    For navy or dark backgrounds (white name, white collar, yellow tagline)
  mono-dark   Single dark colour (print, stamps)
  mono-white  Single white colour (on photos / dark)

WHICH FILE GOES WHERE ON THE WEBSITE
  Header logo        SVG/BrainInteracts_Horizontal_color.svg
  Footer (dark)      SVG/BrainInteracts_Horizontal_reversed.svg
  Browser tab icon   Website-icons/favicon.ico + favicon.svg
  Link previews      Social/og-image-1200x630.png

FOR YOUR DEVELOPER (paste inside <head>):
  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="manifest" href="/site.webmanifest">
  <meta property="og:image" content="https://braininteracts.com/og-image-1200x630.png">

Text in the logo files is converted to shapes, so no fonts need to be installed.
Fonts used: Space Grotesk Bold (name), Inter SemiBold (tagline) - both free on Google Fonts.
